/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./ts/PageScript/EditableContentManager.ts
const maxConsequentCalls = 2;
const maxConsequentCallsPeriodMs = 200;
const cacheLifetimeMs = 500;
class EditableContentManager {
    constructor() {
        this._newElementsObserverConfig = {
            subtree: true, childList: true
        };
    }
    beginEditableContentHandling(doc) {
        this.overrideCssStyleDeclaration(doc);
        doc.addEventListener("DOMContentLoaded", () => {
            doc.querySelectorAll('[contenteditable="true"]').forEach(tag => {
                this.overrideInnerHtml(tag);
            });
        });
        new MutationObserver(this.newElementsObserverCallback.bind(this))
            .observe(doc.documentElement, this._newElementsObserverConfig);
    }
    newElementsObserverCallback(mutations, observer) {
        for (const mutation of mutations) {
            if (mutation.target instanceof HTMLElement &&
                mutation.target.contentEditable === "true") {
                this.overrideInnerHtml(mutation.target);
            }
        }
    }
    overrideInnerHtml(tag) {
        if (!tag.innerHtmlGetter) {
            tag.innerHtmlGetter = tag.__lookupGetter__('innerHTML');
            Object.defineProperty(tag, "innerHTML", {
                get: this.getInnerHtml.bind(this, tag),
                set: tag.__lookupSetter__('innerHTML').bind(tag)
            });
        }
    }
    getInnerHtml(tag) {
        if (tag.innerHtmlCache &&
            tag.innerHtmlCache.consequentCalls > maxConsequentCalls &&
            Date.now() - tag.innerHtmlCache.timestamp < cacheLifetimeMs) {
            return tag.innerHtmlCache.value;
        }
        tag.dispatchEvent(new CustomEvent("before-get-inner-html", { bubbles: true }));
        const consequentCalls = tag.innerHtmlCache &&
            Date.now() - tag.innerHtmlCache.timestamp < maxConsequentCallsPeriodMs
            ? tag.innerHtmlCache.consequentCalls + 1 : 1;
        tag.innerHtmlCache = {
            value: tag.innerHtmlGetter(), timestamp: Date.now(),
            consequentCalls: consequentCalls
        };
        tag.dispatchEvent(new CustomEvent("after-get-inner-html", { bubbles: false }));
        return tag.innerHtmlCache.value;
    }
    overrideCssStyleDeclaration(doc) {
        Object.defineProperty(doc.body.style.__proto__, "color", {
            configurable: true,
            get: this.getColor,
            set: this.setColor
        });
    }
    setColor(value) {
        this.setProperty("color", value);
    }
    getColor() {
        return this.getPropertyValue("--original-color") ||
            this.getPropertyValue("color");
    }
}

// CONCATENATED MODULE: ./ts/PageScript/QueryCommandManager.ts
class QueryCommandManager {
    overrideQueryCommandValue(doc) {
        if (!doc.originalQueryCommandValue) {
            doc.originalQueryCommandValue = doc.queryCommandValue.bind(doc);
            doc.queryCommandValue = this.queryCommandValue.bind(this, doc);
        }
    }
    queryCommandValue(doc, command) {
        if (command === "foreColor" || command === "backColor") {
            let selection = doc.defaultView.getSelection();
            if (selection) {
                let range = selection.getRangeAt(0);
                if (range && range.commonAncestorContainer) {
                    let curPosElement = range.commonAncestorContainer instanceof HTMLElement
                        ? range.commonAncestorContainer
                        : range.commonAncestorContainer.parentElement;
                    if (curPosElement) {
                        let result;
                        switch (command) {
                            case "foreColor":
                                if (result = curPosElement.style.getPropertyValue("--original-color")) {
                                    return result;
                                }
                                break;
                            case "backColor":
                                if (result = curPosElement.style.getPropertyValue("--original-background-color")) {
                                    return result;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }
        return doc.originalQueryCommandValue(command);
    }
}

// CONCATENATED MODULE: ./ts/PageScript/PageScriptStarter.ts


new EditableContentManager().beginEditableContentHandling(document);
new QueryCommandManager().overrideQueryCommandValue(document);
document.documentElement.dispatchEvent(new CustomEvent("PageScriptLoaded"));


/***/ })
/******/ ]);