$(function(){var breadcrumbItems=$('.page-header-breadcrumb .breadcrumb-item').length
if(!$('body').hasClass('mobiletheme')&&!$('body').hasClass('tablettheme')&&breadcrumbItems>5){$('.page-header-breadcrumb .breadcrumb-item').each(function(index,item){if(index>breadcrumbItems-4){return!1}
var $this=$(item).find('a')
if($this.length===0){return}
var width=$this.width()+1
$this.addClass('breadcrumb-item-hover')
$this.on('mouseenter',function(){$this.css('max-width',width)})
$this.on('mouseleave',function(){$this.css('max-width','')})})}
var $navdrawer=$('#nav-drawer')
var sessionStorageSupport=!0
if(typeof Storage!==' undefined'){try{sessionStorage.setItem('unsw-moodle-test','true')
sessionStorage.removeItem('unsw-moodle-test')}catch{sessionStorageSupport=!1}}else{sessionStorageSupport=!1}
if(sessionStorageSupport&&sessionStorage.getItem('unsw-navdrawer-hide')){$('[data-toggle="navdrawer"]').addClass('toggled')
$('#nav-drawer').addClass('desktop-hide')}
$('[data-toggle="navdrawer"]').on('click',function(){if(window.innerWidth>991){$('[data-toggle="navdrawer"]').toggleClass('toggled')
$navdrawer.toggleClass('desktop-hide')
if(sessionStorageSupport){if($navdrawer.hasClass('desktop-hide')){sessionStorage.setItem('unsw-navdrawer-hide',!0)}else if(sessionStorage.getItem('unsw-navdrawer-hide')){sessionStorage.removeItem('unsw-navdrawer-hide')}}}else{$navdrawer.toggleClass('mobile-show')}})
var $bd=$('body')
$('.theatre-control-off').on('click',function(){$bd.removeClass('theatre-on')
sessionStorage.setItem('theatre','off')})
$('.theatre-control-on').on('click',function(){$bd.addClass('theatre-on')
sessionStorage.setItem('theatre','on')})
if(sessionStorage.getItem('theatre')==='on'){$bd.addClass('theatre-on')}})